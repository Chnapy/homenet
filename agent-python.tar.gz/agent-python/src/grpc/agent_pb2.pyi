from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AgentOS(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNKNOWN_OS: _ClassVar[AgentOS]
    OPENWRT_GLINET: _ClassVar[AgentOS]
    HAOS: _ClassVar[AgentOS]
    PROXMOX: _ClassVar[AgentOS]
    ANDROID_TV: _ClassVar[AgentOS]
    WINDOWS: _ClassVar[AgentOS]
    DEBIAN: _ClassVar[AgentOS]
UNKNOWN_OS: AgentOS
OPENWRT_GLINET: AgentOS
HAOS: AgentOS
PROXMOX: AgentOS
ANDROID_TV: AgentOS
WINDOWS: AgentOS
DEBIAN: AgentOS

class AgentMetadata(_message.Message):
    __slots__ = ("releaseID", "computeStartTime", "computeDuration", "env")
    class EnvEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    RELEASEID_FIELD_NUMBER: _ClassVar[int]
    COMPUTESTARTTIME_FIELD_NUMBER: _ClassVar[int]
    COMPUTEDURATION_FIELD_NUMBER: _ClassVar[int]
    ENV_FIELD_NUMBER: _ClassVar[int]
    releaseID: int
    computeStartTime: int
    computeDuration: int
    env: _containers.ScalarMap[str, str]
    def __init__(self, releaseID: _Optional[int] = ..., computeStartTime: _Optional[int] = ..., computeDuration: _Optional[int] = ..., env: _Optional[_Mapping[str, str]] = ...) -> None: ...

class AgentWebItem(_message.Message):
    __slots__ = ("port", "ssl")
    PORT_FIELD_NUMBER: _ClassVar[int]
    SSL_FIELD_NUMBER: _ClassVar[int]
    port: int
    ssl: bool
    def __init__(self, port: _Optional[int] = ..., ssl: bool = ...) -> None: ...

class AgentSSH(_message.Message):
    __slots__ = ("ports",)
    PORTS_FIELD_NUMBER: _ClassVar[int]
    ports: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, ports: _Optional[_Iterable[int]] = ...) -> None: ...

class AgentApp(_message.Message):
    __slots__ = ("slug", "vpnMode", "vpnAddress", "vpnClients", "reverseProxy", "web")
    class AgentAppSlug(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        UNKNOWN_APP: _ClassVar[AgentApp.AgentAppSlug]
        WIREGUARD: _ClassVar[AgentApp.AgentAppSlug]
        NGINX: _ClassVar[AgentApp.AgentAppSlug]
        CADDY: _ClassVar[AgentApp.AgentAppSlug]
        ADGUARD_HOME: _ClassVar[AgentApp.AgentAppSlug]
        NODE_RED: _ClassVar[AgentApp.AgentAppSlug]
        ZIGBEE2MQTT: _ClassVar[AgentApp.AgentAppSlug]
        PLEX: _ClassVar[AgentApp.AgentAppSlug]
        SUNSHINE: _ClassVar[AgentApp.AgentAppSlug]
        UPTIME_KUMA: _ClassVar[AgentApp.AgentAppSlug]
        NTFY: _ClassVar[AgentApp.AgentAppSlug]
        DOCKER: _ClassVar[AgentApp.AgentAppSlug]
        MOONLIGHT: _ClassVar[AgentApp.AgentAppSlug]
        CODE_SERVER: _ClassVar[AgentApp.AgentAppSlug]
    UNKNOWN_APP: AgentApp.AgentAppSlug
    WIREGUARD: AgentApp.AgentAppSlug
    NGINX: AgentApp.AgentAppSlug
    CADDY: AgentApp.AgentAppSlug
    ADGUARD_HOME: AgentApp.AgentAppSlug
    NODE_RED: AgentApp.AgentAppSlug
    ZIGBEE2MQTT: AgentApp.AgentAppSlug
    PLEX: AgentApp.AgentAppSlug
    SUNSHINE: AgentApp.AgentAppSlug
    UPTIME_KUMA: AgentApp.AgentAppSlug
    NTFY: AgentApp.AgentAppSlug
    DOCKER: AgentApp.AgentAppSlug
    MOONLIGHT: AgentApp.AgentAppSlug
    CODE_SERVER: AgentApp.AgentAppSlug
    class AgentVpnMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        UNKNOWN_VPN: _ClassVar[AgentApp.AgentVpnMode]
        CLIENT: _ClassVar[AgentApp.AgentVpnMode]
        SERVER: _ClassVar[AgentApp.AgentVpnMode]
    UNKNOWN_VPN: AgentApp.AgentVpnMode
    CLIENT: AgentApp.AgentVpnMode
    SERVER: AgentApp.AgentVpnMode
    class AgentReverseProxy(_message.Message):
        __slots__ = ("fromDomain", "toAddress")
        class From(_message.Message):
            __slots__ = ("domain", "ssl")
            DOMAIN_FIELD_NUMBER: _ClassVar[int]
            SSL_FIELD_NUMBER: _ClassVar[int]
            domain: str
            ssl: bool
            def __init__(self, domain: _Optional[str] = ..., ssl: bool = ...) -> None: ...
        class To(_message.Message):
            __slots__ = ("address", "ssl", "port")
            ADDRESS_FIELD_NUMBER: _ClassVar[int]
            SSL_FIELD_NUMBER: _ClassVar[int]
            PORT_FIELD_NUMBER: _ClassVar[int]
            address: str
            ssl: bool
            port: int
            def __init__(self, address: _Optional[str] = ..., ssl: bool = ..., port: _Optional[int] = ...) -> None: ...
        FROMDOMAIN_FIELD_NUMBER: _ClassVar[int]
        TOADDRESS_FIELD_NUMBER: _ClassVar[int]
        fromDomain: AgentApp.AgentReverseProxy.From
        toAddress: AgentApp.AgentReverseProxy.To
        def __init__(self, fromDomain: _Optional[_Union[AgentApp.AgentReverseProxy.From, _Mapping]] = ..., toAddress: _Optional[_Union[AgentApp.AgentReverseProxy.To, _Mapping]] = ...) -> None: ...
    SLUG_FIELD_NUMBER: _ClassVar[int]
    VPNMODE_FIELD_NUMBER: _ClassVar[int]
    VPNADDRESS_FIELD_NUMBER: _ClassVar[int]
    VPNCLIENTS_FIELD_NUMBER: _ClassVar[int]
    REVERSEPROXY_FIELD_NUMBER: _ClassVar[int]
    WEB_FIELD_NUMBER: _ClassVar[int]
    slug: AgentApp.AgentAppSlug
    vpnMode: AgentApp.AgentVpnMode
    vpnAddress: str
    vpnClients: _containers.RepeatedScalarFieldContainer[str]
    reverseProxy: _containers.RepeatedCompositeFieldContainer[AgentApp.AgentReverseProxy]
    web: _containers.RepeatedCompositeFieldContainer[AgentWebItem]
    def __init__(self, slug: _Optional[_Union[AgentApp.AgentAppSlug, str]] = ..., vpnMode: _Optional[_Union[AgentApp.AgentVpnMode, str]] = ..., vpnAddress: _Optional[str] = ..., vpnClients: _Optional[_Iterable[str]] = ..., reverseProxy: _Optional[_Iterable[_Union[AgentApp.AgentReverseProxy, _Mapping]]] = ..., web: _Optional[_Iterable[_Union[AgentWebItem, _Mapping]]] = ...) -> None: ...

class AgentInstance(_message.Message):
    __slots__ = ("type", "os", "unknownOS", "lan", "wan", "ddns", "dhcp", "web", "ssh", "apps", "instances")
    class AgentInstanceType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        UNKNOWN_TYPE: _ClassVar[AgentInstance.AgentInstanceType]
        DEVICE: _ClassVar[AgentInstance.AgentInstanceType]
        PROXMOX: _ClassVar[AgentInstance.AgentInstanceType]
        DOCKER: _ClassVar[AgentInstance.AgentInstanceType]
    UNKNOWN_TYPE: AgentInstance.AgentInstanceType
    DEVICE: AgentInstance.AgentInstanceType
    PROXMOX: AgentInstance.AgentInstanceType
    DOCKER: AgentInstance.AgentInstanceType
    class AgentDHCPItem(_message.Message):
        __slots__ = ("address", "alias")
        ADDRESS_FIELD_NUMBER: _ClassVar[int]
        ALIAS_FIELD_NUMBER: _ClassVar[int]
        address: str
        alias: str
        def __init__(self, address: _Optional[str] = ..., alias: _Optional[str] = ...) -> None: ...
    TYPE_FIELD_NUMBER: _ClassVar[int]
    OS_FIELD_NUMBER: _ClassVar[int]
    UNKNOWNOS_FIELD_NUMBER: _ClassVar[int]
    LAN_FIELD_NUMBER: _ClassVar[int]
    WAN_FIELD_NUMBER: _ClassVar[int]
    DDNS_FIELD_NUMBER: _ClassVar[int]
    DHCP_FIELD_NUMBER: _ClassVar[int]
    WEB_FIELD_NUMBER: _ClassVar[int]
    SSH_FIELD_NUMBER: _ClassVar[int]
    APPS_FIELD_NUMBER: _ClassVar[int]
    INSTANCES_FIELD_NUMBER: _ClassVar[int]
    type: AgentInstance.AgentInstanceType
    os: AgentOS
    unknownOS: str
    lan: str
    wan: str
    ddns: str
    dhcp: _containers.RepeatedCompositeFieldContainer[AgentInstance.AgentDHCPItem]
    web: _containers.RepeatedCompositeFieldContainer[AgentWebItem]
    ssh: AgentSSH
    apps: _containers.RepeatedCompositeFieldContainer[AgentApp]
    instances: _containers.RepeatedCompositeFieldContainer[AgentInstance]
    def __init__(self, type: _Optional[_Union[AgentInstance.AgentInstanceType, str]] = ..., os: _Optional[_Union[AgentOS, str]] = ..., unknownOS: _Optional[str] = ..., lan: _Optional[str] = ..., wan: _Optional[str] = ..., ddns: _Optional[str] = ..., dhcp: _Optional[_Iterable[_Union[AgentInstance.AgentDHCPItem, _Mapping]]] = ..., web: _Optional[_Iterable[_Union[AgentWebItem, _Mapping]]] = ..., ssh: _Optional[_Union[AgentSSH, _Mapping]] = ..., apps: _Optional[_Iterable[_Union[AgentApp, _Mapping]]] = ..., instances: _Optional[_Iterable[_Union[AgentInstance, _Mapping]]] = ...) -> None: ...

class AgentUpdateRequest(_message.Message):
    __slots__ = ("agentMetadata", "device")
    class AgentDHCPItem(_message.Message):
        __slots__ = ("address", "alias")
        ADDRESS_FIELD_NUMBER: _ClassVar[int]
        ALIAS_FIELD_NUMBER: _ClassVar[int]
        address: str
        alias: str
        def __init__(self, address: _Optional[str] = ..., alias: _Optional[str] = ...) -> None: ...
    AGENTMETADATA_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    agentMetadata: AgentMetadata
    device: AgentInstance
    def __init__(self, agentMetadata: _Optional[_Union[AgentMetadata, _Mapping]] = ..., device: _Optional[_Union[AgentInstance, _Mapping]] = ...) -> None: ...

class AgentUpdateResponse(_message.Message):
    __slots__ = ("foo",)
    FOO_FIELD_NUMBER: _ClassVar[int]
    foo: str
    def __init__(self, foo: _Optional[str] = ...) -> None: ...
